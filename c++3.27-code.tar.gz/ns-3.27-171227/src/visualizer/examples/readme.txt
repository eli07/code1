For activating the visualizer, with any example, just pass the option
--SimulatorImplementationType=ns3::VisualSimulatorImpl to it, assuming
the script uses ns-3's command line parser (class CommandLine).
