import numpy as np
import sys

LARGE_SNR = np.float32(999)

REFERENCE_LOSS = 46.6777
REFERENCE_DIST = 1
EXPONENT       = 3
TX_POWER       = 20
CS_THRESHOLD   = np.float32(sys.argv[1])
NOISE_FLOOR_DB = -93.97
SNR_THRESHOLD  = 23
SEED           = np.int(sys.argv[2])

# utility functions ------------------------------------------------------------
def GetDist(a,b):
  return np.sqrt(np.square(a[0]-b[0]) + np.square(a[1]-b[1]))

def DB2W(p_db):
  return np.power(10, p_db/10)

def W2DB(p):
  return 10 * np.log10(p)

def GetPathLossDB(distance):
  if(distance <= REFERENCE_DIST):
    return REFERENCE_LOSS
  else:
    return REFERENCE_LOSS + 10*EXPONENT*np.log10(distance/REFERENCE_DIST)

def GetRxPowerDB(a,b):
  return TX_POWER - GetPathLossDB(GetDist(a,b))

def CarrierSense(node, tx_vector, stas, aps):
  total_interference_w = 0.0
  for i in range(NUM_NODES):
    if tx_vector[i] == 1:
      total_interference_w += DB2W(GetRxPowerDB(stas[i], stas[node]))
  if(total_interference_w == 0.0):
    return False
  total_interference_db = W2DB(total_interference_w)
  if(total_interference_db > CS_THRESHOLD):
    return True
  else:
    return False

def Transmit(tx_vector, stas, aps):
  rx_vector = np.copy(tx_vector)
  rx_snr = np.copy(tx_vector)
  for i in range(NUM_NODES):
    if tx_vector[i] == 1:
      signal_db = GetRxPowerDB(stas[i], aps[assoc[i]])
      total_noise_w = DB2W(NOISE_FLOOR_DB)
      for j in range(NUM_NODES):
        if i==j or tx_vector[j] == 0:
          continue
        total_noise_w += DB2W(GetRxPowerDB(stas[j], aps[assoc[i]]))
      total_noise_db = W2DB(total_noise_w)
      snr_db = signal_db - total_noise_db
      rx_snr[i] = snr_db
      if(snr_db < SNR_THRESHOLD):
        rx_vector[i] = 0
    else:
      rx_snr[i] = LARGE_SNR 
  return rx_vector, rx_snr
#-------------------------------------------------------------------------------

np.random.seed(SEED)
buf = np.loadtxt(str("middle/positions_c%03d_s%04d.txt"%(-CS_THRESHOLD,SEED)))
aps = buf[:,0:2]
stas = buf[:,2:4]
NUM_NODES = stas.shape[0]

# associate stations with APs
assoc = np.zeros(NUM_NODES)
for i in range(NUM_NODES):
  assoc[i] = np.argmin(np.sum(np.square(stas[i]-aps),1))
assoc = assoc.astype(np.int)

# the nodes form groups
group_id = np.arange(NUM_NODES)+1
while True:
  diff = False
  draw = np.arange(NUM_NODES)
  np.random.shuffle(draw)
  for i in range(NUM_NODES):
    curr_sta = np.int(draw[i])
    draw2 = np.arange(NUM_NODES)
    np.random.shuffle(draw2)
    for j in range(NUM_NODES):
      curr_sta2 = np.int(draw2[j])
      # compare group size
      if group_id[curr_sta2] == group_id[curr_sta]:
        continue
      if np.sum(group_id==group_id[curr_sta]) > np.sum(group_id==group_id[curr_sta2])+1:
        continue
      if np.sum(group_id==group_id[curr_sta]) == np.sum(group_id==group_id[curr_sta2])+1:
        tx_vector = np.zeros(NUM_NODES)
        for k in range(NUM_NODES):
          if(group_id[k]==group_id[curr_sta]):
            tx_vector[k] = 1
        curr_snr = Transmit(tx_vector, stas, aps)[1]
        tx_vector = np.zeros(NUM_NODES)
        tx_vector[curr_sta] = 1
        for k in range(NUM_NODES):
          if(group_id[k]==group_id[curr_sta2]):
            tx_vector[k] = 1
        new_snr = Transmit(tx_vector, stas, aps)[1]
        if(np.min(curr_snr) >= np.min(new_snr)):
          continue
      if GetRxPowerDB(stas[curr_sta], stas[curr_sta2]) < CS_THRESHOLD:
        continue
      # test concurrent transmission
      tx_vector = np.zeros(NUM_NODES)
      tx_vector[curr_sta] = 1
      tx_vector[np.nonzero(group_id==group_id[curr_sta2])[0]] = 1
      rx_vector = Transmit(tx_vector, stas, aps)[0]
      if np.sum(rx_vector) == np.sum(tx_vector):
        group_id[curr_sta] = group_id[curr_sta2]
        #print("node %d joins group %d"%(curr_sta, group_id[curr_sta2]))
        diff = True
        break
  if diff == False:
    break

count = 0
concurrent = 0
for i in range(NUM_NODES):
  if np.sum(group_id==i) > 0:
    count += 1
    concurrent += np.sum(group_id==i)
avg_group_size = concurrent / count
print("avg_group_size: %.2f"%avg_group_size)

out_str = np.zeros((NUM_NODES, 2))
out_str[:,0] = np.arange(NUM_NODES);
out_str[:,1] = group_id

np.savetxt(str("middle/groupid_c%03d_s%04d.txt"%(-CS_THRESHOLD,SEED)), out_str, fmt='%d')

