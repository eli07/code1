#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/random-variable-stream.h"
#include "ns3/config-store-module.h"
#include "ns3/wifi-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/olsr-helper.h"
#include "ns3/ipv4-header.h"
#include "ns3/tcp-header.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <cstdlib>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("SimulationScript");

// Global variables ------------------------------------------------------------
Ptr<UniformRandomVariable> m_random;
uint16_t num_aps;
uint16_t num_stas;
uint16_t num_stas_per_ap;
double begin_time;
double sim_time;
uint32_t payloadSize;
uint16_t num_grids;
uint16_t grid_size;

double pre_begin_time;
double pre_interval;
double pre_duration;

int16_t cs_threshold;
uint16_t protocol;
uint32_t seed;

NetDeviceContainer apDevices;
NetDeviceContainer staDevices;

static void ResetStatistics(void) {
  for(uint32_t i=0; i<num_stas; i++) {
    Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
    device->ResetAckStat();
  }
}

static void ApplyCSThreshold(void) {
  for(uint16_t i=0; i<num_aps; i++) {
    Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(apDevices.Get(i));
    //device->GetPhy()->SetEdThreshold((double)cs_threshold);
    device->GetPhy()->SetCcaMode1Threshold((double)cs_threshold);
    for(uint16_t j=0; j<num_stas_per_ap; j++) {
      Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i*num_stas_per_ap+j));
      //device->GetPhy()->SetEdThreshold((double)cs_threshold);
      device->GetPhy()->SetCcaMode1Threshold((double)cs_threshold);
    }
  }
}

static void PrintProgress(void) {
  fprintf(stderr, ".");
  if(Simulator::Now() > Seconds(begin_time + sim_time - 0.1/2)) fprintf(stderr, "\n");
  Simulator::Schedule(Seconds(0.1), &PrintProgress);
}

int main(int argc, char *argv[]) {

  // Parameters initialization -------------------------------------------------
  m_random 		    = CreateObject<UniformRandomVariable>();
  num_grids         = 5;
  grid_size         = 10;
  num_stas_per_ap   = 1;
  num_aps 		    = num_grids*num_grids;
  num_stas 		    = num_aps*num_stas_per_ap;
  begin_time 	    = 1000.0;
  sim_time 		    = 1.0;
  payloadSize       = 1472;

  pre_begin_time = 100.0;
  pre_interval = 1.0;
  pre_duration = 0.01;

  // Simulation Parameters
  cs_threshold = -99;
  protocol = 0;
  seed = 0;

  // Process command line arguments --------------------------------------------
  CommandLine cmd;
  cmd.AddValue("seed", "Random seed", seed);
  cmd.AddValue("cs", "CS threshold", cs_threshold);
  cmd.AddValue("proto", "Protocol", protocol);
  cmd.AddValue("time", "Simulation Time", sim_time);
  cmd.Parse(argc, argv);

  m_random->SetStream(seed);

  // Create nodes --------------------------------------------------------------
  NodeContainer apNodes;
  apNodes.Create(num_aps);
  NodeContainer staNodes;
  staNodes.Create(num_stas);

  // Channel -------------------------------------------------------------------
  YansWifiChannelHelper channel;
  channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel");
  channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");

  // PHY -----------------------------------------------------------------------
  YansWifiPhyHelper phy = YansWifiPhyHelper::Default();
  phy.SetChannel(channel.Create());
  phy.Set("ShortGuardEnabled", BooleanValue(1));
  phy.Set("TxPowerStart", DoubleValue(20.0));
  phy.Set("TxPowerEnd", DoubleValue(20.0));
  phy.Set("EnergyDetectionThreshold", DoubleValue(-96)); 
  phy.Set("CcaMode1Threshold", DoubleValue(-99)); 
  Config::Set("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/ChannelWidth", UintegerValue(20));

  // MAC -----------------------------------------------------------------------
  WifiMacHelper mac;
  mac.SetType("ns3::AdhocWifiMac");
 
  // Network interface ---------------------------------------------------------
  WifiHelper wifi;
  wifi.SetStandard(WIFI_PHY_STANDARD_80211a);
  std::string dataMode("OfdmRate54Mbps");
  wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode", StringValue(dataMode));
  apDevices = wifi.Install(phy, mac, apNodes);
  staDevices = wifi.Install(phy, mac, staNodes);

  // Node positions ------------------------------------------------------------
  MobilityHelper mobility;
  Ptr<ListPositionAllocator> apPositionAlloc = CreateObject<ListPositionAllocator>();
  for(uint16_t i=0; i<num_aps; i++) {
    double x = double(i%num_grids*grid_size+grid_size/2);
    double y = double(i/num_grids*grid_size+grid_size/2);
    apPositionAlloc->Add(Vector(x, y, 0.0));
    NS_LOG_UNCOND("ap position: " << x << " " << y);
  }
  mobility.SetPositionAllocator(apPositionAlloc);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(apNodes);

  Ptr<ListPositionAllocator> staPositionAlloc = CreateObject<ListPositionAllocator>();
  for(uint16_t i=0; i<num_aps; i++) {
    for(uint16_t j=0; j<num_stas_per_ap; j++) {
      double rvx = m_random->GetValue()*grid_size;
      double rvy = m_random->GetValue()*grid_size;
      double x = rvx + (double)(i%num_grids*grid_size);
      double y = rvy + (double)(i/num_grids*grid_size);
      staPositionAlloc->Add(Vector(x, y, 0.0));
      NS_LOG_UNCOND("sta position: " << x << " " << y);
    }
  }
  mobility.SetPositionAllocator(staPositionAlloc);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(staNodes);
  
  // Set frame capture model ---------------------------------------------------
  Ptr<SimpleFrameCaptureModel> frameCaptureModel = CreateObject<SimpleFrameCaptureModel>();
  frameCaptureModel->SetMargin(10);
  Ptr<WifiNetDevice> device;
  for(uint32_t i=0; i<num_aps; i++) {
    device = DynamicCast<WifiNetDevice>(apDevices.Get(i));
    device->GetPhy()->SetFrameCaptureModel(frameCaptureModel);
  }
  for(uint32_t i=0; i<num_stas; i++) {
    device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
    device->GetPhy()->SetFrameCaptureModel(frameCaptureModel);
  }
 
  if(protocol==1) {
    // PROPOSED: Set Group ID ----------------------------------------------------
    char outfilename[200];
    sprintf(outfilename, "middle/positions_c%03d_s%04d.txt", -cs_threshold, seed);
    FILE *outfile = fopen(outfilename, "w");
    for(uint16_t i=0; i<num_aps; i++) {
      Vector ap = apPositionAlloc->GetNext();
      fprintf(outfile, " %d %8.3f %8.3f\n", 1, ap.x, ap.y);
    }
    for(uint16_t j=0; j<num_stas; j++) {
        Vector sta = staPositionAlloc->GetNext();
        fprintf(outfile, " %d %8.3f %8.3f\n", 0, sta.x, sta.y);
    }
    fclose(outfile);

    NS_LOG_UNCOND("Calculating groups...");
  
    char syscmd[100];
    sprintf(syscmd, "python3 make_group.py %d %d", cs_threshold, seed);
    system(syscmd);

    char infilename[200];
    sprintf(infilename, "middle/groupid_c%03d_s%04d.txt", -cs_threshold, seed);
    FILE *infile = fopen(infilename, "r");
    uint32_t addr, group;
    for(uint16_t i=0; i<num_stas; i++) {
      fscanf(infile, "%d %d", &addr, &group);
      Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
      device->GetPhy()->SetGroupID(group);
    }
    for(uint16_t i=0; i<num_aps; i++) {
      Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(apDevices.Get(i));
      device->GetPhy()->SetGroupID(0);
      device->GetPhy()->SetBssColor(i);
      for(uint16_t j=0; j<num_stas_per_ap; j++) {
        Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i*num_stas_per_ap+j));
        device->GetPhy()->SetBssColor(i);
      }    
    }
    fclose(infile);
  } else {
    Ptr<WifiNetDevice> device;
    for(uint16_t i=0; i<num_aps; i++) {
      Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(apDevices.Get(i));
      device->GetPhy()->SetGroupID(0);
      device->GetPhy()->SetBssColor(i);
      for(uint16_t j=0; j<num_stas_per_ap; j++) {
        Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i*num_stas_per_ap+j));
        device->GetPhy()->SetGroupID(0);
        device->GetPhy()->SetBssColor(i);
      }
    }
  }
  //----------------------------------------------------------------------------

  uint16_t group_id[num_stas];
  uint16_t group_size[num_stas];
  for(uint16_t i=0; i<num_stas; i++) {
    Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
    group_id[i] = device->GetPhy()->GetGroupID();
  }
  for(uint16_t i=0; i<num_stas; i++) {
    uint16_t count = 0;
    for(uint16_t j=0; j<num_stas; j++) {
      if(group_id[i] == group_id[j]) count++;
    }
    group_size[i] = count;
    if(group_id[i] == 0) group_size[i] = 1;
  }
 
  /*
  if(protocol==1) {
    for(uint16_t i=0; i<num_stas; i++ ) {
      Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
      device->GetPhy()->SetGroupSize(group_size[i]);
    }
  }
  */

  // IP ------------------------------------------------------------------------
  InternetStackHelper internet;
  Ipv4AddressHelper address;
  internet.Install(apNodes);
  internet.Install(staNodes);
  address.SetBase("192.168.0.0", "255.255.0.0");
  Ipv4InterfaceContainer staNodeInterface;
  Ipv4InterfaceContainer apNodeInterface;
  apNodeInterface = address.Assign(apDevices);
  staNodeInterface = address.Assign(staDevices);

  for(uint16_t i=0; i<num_aps; i++) {
    UdpServerHelper myServerPre(19);
    ApplicationContainer serverAppPre = myServerPre.Install(apNodes.Get(i));
    serverAppPre.Start(Seconds(begin_time));
    serverAppPre.Stop(Seconds(begin_time+sim_time));
    for(uint16_t j=0; j<num_stas_per_ap; j++) {
      UdpClientHelper myClientPre(apNodeInterface.GetAddress(i), 19);
      myClientPre.SetAttribute("MaxPackets", UintegerValue(4294967295u));
      myClientPre.SetAttribute("Interval", TimeValue(Time("0.001")));
      myClientPre.SetAttribute("PacketSize", UintegerValue(payloadSize));
      ApplicationContainer clientAppPre = myClientPre.Install(staNodes.Get(i*num_stas_per_ap+j));
      clientAppPre.Start(Seconds(pre_begin_time+pre_interval*(i*num_stas_per_ap+j)));
      clientAppPre.Stop(Seconds(pre_begin_time+pre_interval*(i*num_stas_per_ap+j)+pre_duration));
    }
  }

  // Traffic -------------------------------------------------------------------
  std::vector<ApplicationContainer> servers;

  for(uint16_t i=0; i<num_aps; i++) {
    UdpServerHelper myServer(9);
    ApplicationContainer serverApp = myServer.Install(apNodes.Get(i));
    serverApp.Start(Seconds(begin_time));
    serverApp.Stop(Seconds(begin_time+sim_time));
    servers.push_back(serverApp);
    for(uint16_t j=0; j<num_stas_per_ap; j++) {
      UdpClientHelper myClient(apNodeInterface.GetAddress(i), 9);
      myClient.SetAttribute("MaxPackets", UintegerValue(4294967295u));
      myClient.SetAttribute("Interval", TimeValue(Seconds(0.0002)));
      myClient.SetAttribute("PacketSize", UintegerValue(payloadSize));
      ApplicationContainer clientApp = myClient.Install(staNodes.Get(i*num_stas_per_ap+j));
      clientApp.Start(Seconds(begin_time+0.001*(i*num_stas_per_ap+j)));
      clientApp.Stop(Seconds(begin_time+sim_time));
    }
  }

  Simulator::Schedule(Seconds(begin_time-1.0), &ApplyCSThreshold);
  Simulator::Schedule(Seconds(begin_time-1.0), &ResetStatistics);
  Simulator::Schedule(Seconds(begin_time), &PrintProgress);
  
  // Run simulation ------------------------------------------------------------
  Simulator::Stop(Seconds(begin_time+sim_time+0.1));
  Simulator::Run();
  Simulator::Destroy();

  // Throughput calculation ----------------------------------------------------
  double total_throughput = 0.0;
  for(uint16_t i=0; i<num_aps; i++) {
    uint32_t totalPacketsThrough = DynamicCast<UdpServer>(servers[i].Get(0))->GetReceived();
    double throughput = totalPacketsThrough * payloadSize * 8 / (sim_time * 1000000.0); //Mbps
    total_throughput += throughput;
    NS_LOG_UNCOND("throughput: " << throughput << "Mbps");
  }

  uint32_t total_num_got = 0;
  uint64_t total_num_got_sq = 0;
  uint32_t total_num_miss = 0;
  for(uint32_t i=0; i<num_stas; i++) {
    Ptr<WifiNetDevice> device = DynamicCast<WifiNetDevice>(staDevices.Get(i));
    uint32_t ack = device->GetNumGotAck();
    NS_LOG_UNCOND("Node " << i << " group size: " << group_size[i] << " packets sent: " << ack);
    total_num_got += ack;
    total_num_got_sq += ack * ack;
    total_num_miss += device->GetNumMissedAck();
  }
  double fairness_index = pow((double)total_num_got, 2) / (num_stas * (double)total_num_got_sq);

  NS_LOG_UNCOND(" ");
  NS_LOG_UNCOND("total throughput: " << total_throughput << "Mbps");
  NS_LOG_UNCOND("number of acks received: " << total_num_got);
  NS_LOG_UNCOND("number of acks missed:   " << total_num_miss);

  NS_LOG_UNCOND("Jain's fairness index:   " << fairness_index);

  char outfilename[200];
  sprintf(outfilename, "data/tput_p%01d_c%03d_s%04d.txt", protocol, -cs_threshold, seed);
  FILE *outfile = fopen(outfilename, "w");
  fprintf(outfile, " %d %d %8.3f %d %d %8.3f\n", cs_threshold, seed, total_throughput, total_num_got, total_num_miss, fairness_index);

  return 0;
}


  

